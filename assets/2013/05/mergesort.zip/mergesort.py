import unittest
import collections
import itertools
 
 
def merge_sort(a, b):
    # Be sure the input sequences will be iterators
    a = iter(a)
    b = iter(b)
 
    # Fetch first elements from sequences
    a_next = next(a, StopIteration)
    b_next = next(b, StopIteration)
 
    # Consume the input's sequences
    while (a_next, b_next) != (StopIteration, StopIteration):
        if a_next < b_next:
            yield a_next
            a_next = next(a, StopIteration)
        else:
            yield b_next
            b_next = next(b, StopIteration)
 
 
def merge_sort_with_key(a, b, key=None):
    # Set up iterators over the input sequences
    if key is None:
        a = itertools.izip(a, a)
        b = itertools.izip(b, b)
    else:
        k = lambda x: (key(x), x)
    
        a = itertools.imap(k, a)
        b = itertools.imap(k, b)
 
    # Fetch first elements from sequences
    a_next = next(a, StopIteration)
    b_next = next(b, StopIteration)
 
    # Consume the input's sequences
    while (a_next, b_next) != (StopIteration, StopIteration):
        if (a_next != StopIteration 
            and (b_next == StopIteration or a_next[0] < b_next[0])):
            
            yield a_next[1]
            a_next = next(a, StopIteration)
            
        elif b_next != StopIteration:
            yield b_next[1]
            b_next = next(b, StopIteration)


class MergeSortTests(unittest.TestCase):

	def test_generators(self):
		self.assertEqual(
			tuple(merge_sort(xrange(5), xrange(5, 10))),
			tuple(xrange(10))
		)
        
	def test_same_length(self):
		self.assertEqual(
			tuple(merge_sort([0,2,4,6,8], [1,3,5,7,9])),
			tuple(xrange(10))
		)
        
	def test_first_shorter(self):
		self.assertEqual(
			tuple(merge_sort([0,2,4], [1,3,5,6,7,8,9])),
			tuple(xrange(10))
		)
        
	def test_first_longer(self):
		self.assertEqual(
			tuple(merge_sort([0,1,2,3,4,6,8], [5,7,9])),
			tuple(xrange(10))
		)


class MergeSortWithKeyTests(unittest.TestCase):

	def test_default_key(self):
		self.assertEqual(
			tuple(merge_sort_with_key([0,2,4,6,8], [1,3,5,7,9])),
			tuple(xrange(10))
		)
        
	def test_with_key(self):
		self.assertEqual(
			tuple(merge_sort_with_key(["a","b","c"],[1,2,3], key=str)),
			tuple((1,2,3,"a","b","c"))
		)
        

unittest.main()