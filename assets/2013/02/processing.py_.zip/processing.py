#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function, unicode_literals
from PIL import Image
from multiprocessing.process import Process
from multiprocessing.queues import Queue
import codecs
import datetime
import hashlib
import logging
import multiprocessing
import os
import sys


logger = multiprocessing.log_to_stderr(logging.INFO)


def filename_producer(root_folder, out_queue, consumers):
    # Walk into all subfolders and output every file found
    for root, dirs, filenames in os.walk(root_folder):
        for filename in filenames:
            # Build filename with absolute path
            filename = os.path.abspath(os.path.join(root, filename))
            filename = filename.decode("utf-8")

            # Put it nto the queue
            out_queue.put(filename)

    # Put a number of sentinels equal to the number of workers
    for i in xrange(consumers):
        out_queue.put(StopIteration)


def thumbnail_consumer(in_queue, out_queue, size, thumb_dir):
    # Create thumbnail directory if doesn.t exits
    if not os.path.exists(thumb_dir):
        os.makedirs(thumb_dir)

    while 1:
        # Fetch filename from queue
        filename = in_queue.get()

        # Skip if stop iteration
        if filename == StopIteration:
            break

        # Try to load the file
        try:
            image = Image.open(filename)
        except IOError:
            continue

        logger.info("Processing file %s", os.path.split(filename)[1])

        # Create thumbnail of the file
        image.thumbnail(size, Image.ANTIALIAS)

        # Generate thumbnail's filename by the digest of the image
        digest = hashlib.sha256(image.tostring()).hexdigest()
        thumbnail = "{}.png".format(digest)

        # Save image as PNG
        image.save(os.path.join(thumb_dir, thumbnail), "PNG")

        # Push original filename and thumbnail
        out_queue.put((filename, thumbnail))

    # Send a iteration's stop
    out_queue.put(StopIteration)


def sink_consumer(in_queue, filename, workers):
    # Create folder if doesn't exists
    if os.path.exists(filename):
        os.remove(filename)

    with codecs.open(filename, "wb", encoding="utf-8") as f:
        # Cycle until the number of active workers is greater than 0
        while workers:
            # Fetch item from the queue
            result = in_queue.get()

            if result == StopIteration:
                # It's a stop iteration, decrement number of active workers
                workers -= 1
            else:
                # Unpack item and write the result into the file
                filename, hash_ = result

                f.write("{1}: {0}\n".format(filename, hash_))


if __name__ == "__main__":
    # Save timestamp
    start = datetime.datetime.now()

    # Select number of workers
    if len(sys.argv) == 3:
        workers = int(sys.argv[2])
    else:
        workers = multiprocessing.cpu_count()

    # Create queues
    producer_queue = Queue()
    sink_queue = Queue()

    # Producer
    producer = Process(
        target=filename_producer, args=(sys.argv[1], producer_queue, workers))
    producer.start()

    # Consumers
    consumers = []

    for i in xrange(workers):
        consumer = Process(
            target=thumbnail_consumer,
            args=(producer_queue, sink_queue, (200, 200), "thumbnails")
        )
        consumer.start()
        consumers.append(consumer)

    sink = Process(
        target=sink_consumer, args=(sink_queue, "processed.txt", workers))
    sink.start()

    # Join the sink consumer
    sink.join()

    # Print elapsed time
    logger.info("Finished in %s", datetime.datetime.now() - start)
